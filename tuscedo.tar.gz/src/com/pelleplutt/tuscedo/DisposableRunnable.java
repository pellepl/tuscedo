package com.pelleplutt.tuscedo;

import com.pelleplutt.util.AppSystem.Disposable;

public interface DisposableRunnable extends Disposable, Runnable {

}
