package com.pelleplutt.tuscedo;

public interface Tickable {
  void tick();
}
