package com.pelleplutt.operandi.proc;


public class MAnonInst extends MListMap {
  public final int pc;
  public MAnonInst(int pc) {
    this.pc = pc;
  }
}
