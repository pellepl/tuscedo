package com.pelleplutt.util;

public abstract class LElem {
  public LElem lprev, lnext;
  public Object ldata;

}
