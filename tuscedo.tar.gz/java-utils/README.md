# java-utils
Generic java stuff used in many of my hobby projects.

Contains (yet another) uart driver for Linux and Windows(!), working over sockets.
